#!/bin/bash
javac src/filetransferUDP/*.java -d bin -sourcepath src